#!/bin/bash

java -cp dbcompare-1.0.jar com.oscgp.dbcompare.run.DbCompare "$@"
